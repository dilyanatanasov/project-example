<?php
require_once dirname(__FILE__). "/views/html/heading.html";
require_once dirname(__FILE__). "/views/html/about.html";