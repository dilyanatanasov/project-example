# Example project for the students in NVNA Nikola Vaptsarov

The main goal of this project is to display the technologies covered in the course "Programming of online applications". 
Some of the programming means used in this demonstrative application are:
- php
- js
- html
- css
- mysql
- ajax

The code is written almost exclusively in OOP and is applying the MVC model of communication between the different classes we create.

Disclaimer: this isn't a perfect example but is meant to show different techniques without overengineering the code.
